//
//  ViewController.swift
//  pro app
//
//  Created by Patrick Lee on 6/21/19.
//  Copyright © 2019 spurIQ. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
   
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var tableView: UITableView!
    var cars = ["Mini Cooper"]
    
    let strFileName = "spurIQArrayTest23.txt"
    let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    
    func readDataFromFile(){
        let fileURL = dir?.appendingPathComponent(strFileName)
        let fileManager = FileManager.default
        let pathComponent = dir!.appendingPathComponent(strFileName)
        let filePath = pathComponent.path
        
        if fileManager.fileExists(atPath: filePath){
            cars = NSMutableArray(contentsOf: fileURL!) as![String]
        }
        else {
            writeArrayToFile()
        }
    }
    func writeArrayToFile() {
        let fileURL = dir?.appendingPathComponent(strFileName)
        (cars as NSArray).write(to: fileURL!, atomically: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        cell1.textLabel?.text = cars[indexPath.row]
        return cell1
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    @IBAction func buttonPress(_ sender: Any) {
        if (input.text != ""){
            cars.append(input.text!)
            tableView.reloadData()
            writeArrayToFile()
            input.text = ""
        }
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete){
            cars.remove(at: indexPath.row)
            tableView.reloadData()
            writeArrayToFile()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        readDataFromFile()
    }


}

